import React, { useReducer } from "react";
import DigitButton from "./DigitButton"; 
import "./styles.css";

export const ACTIONS = {
  ADD_DIGIT: 'add-digit',
  CHOOSE_OPERATION: 'choose-operation',
  CLEAR: 'clear',
  DELETE_DIGIT: 'delete-digit',
  EVALUATE: 'evaluate'
};

function reducer(state, action) {
  const { type, payload } = action;
  switch (type) {
    case ACTIONS.ADD_DIGIT:
      return {
        ...state,
        currentOperand: `${state.currentOperand || ""}${payload.digit}`
      };
    case ACTIONS.CHOOSE_OPERATION:
      return {
        ...state,
        operation: payload.operation,
        previousOperand: state.currentOperand,
        currentOperand: ""
      };
    case ACTIONS.CLEAR:
      return {
        currentOperand: "",
        previousOperand: "",
        operation: ""
      };
    case ACTIONS.DELETE_DIGIT:
      return {
        ...state,
        currentOperand: state.currentOperand.slice(0, -1)
      };
    case ACTIONS.EVALUATE:
      const prev = parseFloat(state.previousOperand);
      const current = parseFloat(state.currentOperand);
      let result;
      switch (state.operation) {
        case "+":
          result = prev + current;
          break;
        case "-":
          result = prev - current;
          break;
        case "*":
          result = prev * current;
          break;
        case "/":
          result = prev / current;
          break;
        default:
          result = current;
      }
      return {
        currentOperand: result.toString(),
        previousOperand: "",
        operation: ""
      };
    default:
      return state;
  }
}

function App() {
  const [{ currentOperand, previousOperand, operation }, dispatch] = useReducer(reducer, {
    currentOperand: "",
    previousOperand: "",
    operation: ""
  });

  const handleDigitClick = digit => {
    dispatch({ type: ACTIONS.ADD_DIGIT, payload: { digit } });
  };

  const handleOperationClick = operation => {
    dispatch({ type: ACTIONS.CHOOSE_OPERATION, payload: { operation } });
  };

  const handleClearClick = () => {
    dispatch({ type: ACTIONS.CLEAR });
  };

  const handleDeleteClick = () => {
    dispatch({ type: ACTIONS.DELETE_DIGIT });
  };

  const handleEvaluateClick = () => {
    dispatch({ type: ACTIONS.EVALUATE });
  };

  return (
    <div className="calculator-container">
      <h1 className="heading">USE ME TO MAKE YOUR MATH EASIER</h1>
      <p className="message">USE ME TO MAKE YOUR MATH EASIER</p>
      <div className="calculator-grid">
        <div className="output">
          <div className="previous-operand">{previousOperand} {operation}</div>
          <div className="current-operand">{currentOperand}</div>
        </div>
        <button className="span-two" onClick={handleClearClick}>AC</button>
        <button onClick={handleDeleteClick}>DEL</button>
        <DigitButton digit="÷" onClick={() => handleOperationClick("/")} />
        <DigitButton digit="7" onClick={() => handleDigitClick("7")} />
        <DigitButton digit="8" onClick={() => handleDigitClick("8")} />
        <DigitButton digit="9" onClick={() => handleDigitClick("9")} />
        <DigitButton digit="*" onClick={() => handleOperationClick("*")} />
        <DigitButton digit="4" onClick={() => handleDigitClick("4")} />
        <DigitButton digit="5" onClick={() => handleDigitClick("5")} />
        <DigitButton digit="6" onClick={() => handleDigitClick("6")} />
        <DigitButton digit="+" onClick={() => handleOperationClick("+")} />
        <DigitButton digit="1" onClick={() => handleDigitClick("1")} />
        <DigitButton digit="2" onClick={() => handleDigitClick("2")} />
        <DigitButton digit="3" onClick={() => handleDigitClick("3")} />
        <DigitButton digit="-" onClick={() => handleOperationClick("-")} />
        <DigitButton digit="." onClick={() => handleDigitClick(".")} />
        <DigitButton digit="0" onClick={() => handleDigitClick("0")} />
        <button className="span-two" onClick={handleEvaluateClick}>=</button>
      </div>
    </div>
  );
}

export default App;
