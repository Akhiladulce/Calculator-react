import React from "react";

const DigitButton = ({ digit, onClick }) => {
  return <button onClick={onClick}>{digit}</button>;
};

export default DigitButton;
